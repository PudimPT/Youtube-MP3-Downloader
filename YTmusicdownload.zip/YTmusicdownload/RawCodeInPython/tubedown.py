import os                            #
import youtube_dl                    #
from os import system                #
from youtube_dl import YoutubeDL     #
######################################

url = input ("URL: ")

lister = input ("Playlist?[Yes/No]: ")

print('Downloading the audios...This is gonna take a while if it is a big audio or an big playlist. Just wait...')


##################################################


if  lister == 'Yes':
    boolno = False
    boolyes = True
else:
    boolno = True
    boolyes = False
    

file_path = f'Sounds_Down/'

ydl_opts2 = {
    #'outtmpl': file_path,
    'extract-audio': True,
    'format': 'm4a',
    'nopart': True,
    'noplaylist': boolno,
    'yesplaylist': boolyes,
}

with youtube_dl.YoutubeDL(ydl_opts2) as ydl:
    meta = ydl.extract_info( url, download=True)







print("Done...")